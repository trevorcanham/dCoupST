% EyelinkToolbox:EyelinkTests
% Non-exhaustive tests of eyelink toolbox functions
